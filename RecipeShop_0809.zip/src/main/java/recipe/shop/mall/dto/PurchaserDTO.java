package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class PurchaserDTO {
	private int pnumber;
	private int prnumber;
	private String pname;
}
