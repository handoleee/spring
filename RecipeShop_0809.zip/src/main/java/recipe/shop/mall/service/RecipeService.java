package recipe.shop.mall.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import recipe.shop.mall.dao.RecipeCommentDAO;
import recipe.shop.mall.dao.RecipeDAO;
import recipe.shop.mall.dto.CommentDTO;
import recipe.shop.mall.dto.MaterialDTO;
import recipe.shop.mall.dto.OrderDTO;
import recipe.shop.mall.dto.PurchaserDTO;
import recipe.shop.mall.dto.RecipeDTO;
import recipe.shop.mall.dto.ReportDTO;

@Service
public class RecipeService {

	@Autowired
	private RecipeDAO rdao;
	
	@Autowired
	private RecipeCommentDAO rcdao;
	
	@Autowired
	private HttpSession session;
	
	private ModelAndView mav;
	
	public ModelAndView recipeList() {
		
		mav = new ModelAndView();
		
		List<RecipeDTO> recipeList = rdao.recipeList();
		
		mav.addObject("recipeList", recipeList);
		mav.setViewName("recipelist");
		
		return mav;
	}

	public ModelAndView recipeWrite(RecipeDTO recipe, MaterialDTO material, OrderDTO order) {
		mav = new ModelAndView();
		
		System.out.println("recipeDto : "+recipe);
		System.out.println("materialDTO : "+material);
		System.out.println("orderDTO : "+order);
				
		rdao.recipeWrite(recipe);
		
		int rwn = 0;
		rwn = rdao.recipeWriteNumber();
		
		System.out.println("등록한 레시피 번호 : " + rwn);
		
		material.setMtrnumber(rwn);
		order.setOrnumber(rwn);
		
		System.out.println("레시피번호 가져온 후");
		System.out.println("materialDTO : "+material);
		System.out.println("orderDTO : "+order);
		
		rdao.materialWrite(material);
		rdao.orderWrite(order);
		
		mav.setViewName("redirect:/recipelist");
				
		return mav;
	}

	public ModelAndView recipeView(int rnumber) {
		mav = new ModelAndView();
		
		RecipeDTO recipeView = rdao.recipeView(rnumber);
		recipeView.setRhits(recipeView.getRhits()+1);
		rdao.updateHits(recipeView);
		
		MaterialDTO materialView = rdao.materialView(rnumber);
		OrderDTO orderView = rdao.orderView(rnumber);
		
		List<CommentDTO> commentList = rcdao.recipeCommentList(rnumber);
				
		mav.addObject("recipeView", recipeView);
		mav.addObject("materialView", materialView);
		mav.addObject("orderView", orderView);
		mav.addObject("commentList", commentList);
		
		mav.setViewName("recipeview");
		
		return mav;
	}

	public ModelAndView recipeReport(int rnumber) {
		mav = new ModelAndView();
		RecipeDTO recipeReport = rdao.recipeView(rnumber);
		
		mav.addObject("recipeReport", recipeReport);
		mav.setViewName("recipereport");
		
		return mav;
	}

	public ModelAndView recipeReportProcess(ReportDTO report) {
		mav = new ModelAndView();
		
		rdao.recipeReportProcess(report);
		mav.setViewName("redirect:/recipeview?rnumber="+report.getRprnumber());
		
		return mav;
	}

	public ModelAndView recipeDelete(int rnumber) {
		mav = new ModelAndView();
		rdao.recipeDelete(rnumber);
		
		mav.setViewName("redirect:/recipelist");		
		return mav;
	}

	public ModelAndView recipeUpdate(int rnumber) {
		mav = new ModelAndView();
		
		RecipeDTO recipe = rdao.recipeView(rnumber);
		MaterialDTO material = rdao.materialView(rnumber);
		OrderDTO order = rdao.orderView(rnumber);
		
		mav.addObject("recipe", recipe);
		mav.addObject("material", material);
		mav.addObject("order", order);
		mav.setViewName("recipeupdate");
		return mav;
	}

	public ModelAndView recipeUpdateProcess(RecipeDTO recipe, MaterialDTO material, OrderDTO order) {

		mav = new ModelAndView();
		
		rdao.recipeUpdate(recipe);
		rdao.materialUpdate(material);
		rdao.orderUpdate(order);
		
		mav.setViewName("redirect:/recipeview?rnumber="+recipe.getRnumber());
		return mav;
	}

	public ModelAndView recipeRanking() {
		mav = new ModelAndView();
		
		List<RecipeDTO> recipeRanking = rdao.recipeRanking();
		
		mav.addObject("recipeRanking", recipeRanking);
		mav.setViewName("reciperanking");
		return mav;
	}

	public ModelAndView recipeSearch(String keyword) {
		mav = new ModelAndView();
		
		List<RecipeDTO> recipeList = rdao.recipeSearch(keyword);
		
		mav.addObject("recipeList", recipeList);
		mav.setViewName("recipelist");
		return mav;
	}
	
	public ModelAndView totalReport() {
		mav = new ModelAndView();
		List<ReportDTO> reportList = rdao.totalReport();
		mav.addObject("totalreport", reportList);
		mav.setViewName("reportlist");
		return mav;
	}
	
	public ModelAndView myRecipeList() {
		mav = new ModelAndView();
		session.getAttribute("loginMember");
		List<RecipeDTO> myRecipeList = rdao.myRecipeList();
		mav.addObject("myrecipelist", myRecipeList);
		mav.setViewName("myrecipelist");
		return mav;
	}
	
	public ModelAndView myReport() {
		mav = new ModelAndView();
		session.getAttribute("loginMember");
		List<ReportDTO> reportList = rdao.myReport();
		mav.addObject("totalreport", reportList);
		mav.setViewName("myreport");
		return mav;
	}

	public ModelAndView reportView(int rpnumber) {
		mav = new ModelAndView();
		ReportDTO reportView = rdao.reportView(rpnumber);
		mav.addObject("reportview", reportView);
		mav.setViewName("reportview");
		return mav;
	}
	
	public ModelAndView reportUpdate(int rpnumber) {
		mav = new ModelAndView();
		ReportDTO reportUpdate = rdao.reportUpdate(rpnumber);
		mav.addObject("reportview", reportUpdate);
		mav.setViewName("reportupdate");
		return mav;
	}

	public ModelAndView reportUpdateProcess(ReportDTO report) {
		mav = new ModelAndView();
		int reportUpdateResult = rdao.reportUpdateProcess(report);
		if(reportUpdateResult > 0) {
			mav.setViewName("redirect:/reportlist");
		} 
		return mav;
	}

//	public ModelAndView myBuyRecipe() {
//		mav = new ModelAndView();
//		session.getAttribute("loginMember");
//		List<PurchaserDTO> myBuyRecipe = rdao.myBuyRecipe();
//		mav.addObject("mybuyrecipe", myBuyRecipe);		
//		mav.setViewName("mybuyrecipe");
//		return mav;
//	}
	
}
