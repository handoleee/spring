package recipe.shop.mall.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import recipe.shop.mall.dto.MaterialDTO;
import recipe.shop.mall.dto.OrderDTO;
import recipe.shop.mall.dto.PurchaserDTO;
import recipe.shop.mall.dto.RecipeDTO;
import recipe.shop.mall.dto.ReportDTO;

@Repository
public class RecipeDAO {

	@Autowired
	private SqlSessionTemplate sql;
	
	public List<RecipeDTO> recipeList() {
		return sql.selectList("rm.recipelist");
	}

	public void recipeWrite(RecipeDTO recipe) {
		sql.insert("rm.recipewrite", recipe);
	}

	public int recipeWriteNumber() {
		return sql.selectOne("rm.recipewritenumber");
	}

	public void materialWrite(MaterialDTO material) {
		sql.insert("rm.materialwrite", material);
	}

	public void orderWrite(OrderDTO order) {
		sql.insert("rm.orderwrite", order);
	}

	public RecipeDTO recipeView(int rnumber) {
		return sql.selectOne("rm.recipeview", rnumber);
	}

	public void updateHits(RecipeDTO recipe) {
		sql.update("rm.updatehits", recipe);
	}

	public MaterialDTO materialView(int rnumber) {
		return sql.selectOne("rm.materialview", rnumber);
	}

	public OrderDTO orderView(int rnumber) {
		return sql.selectOne("rm.orderview", rnumber);
	}

	public void recipeReportProcess(ReportDTO report) {
		sql.insert("rm.recipereportprocess", report);
	}

	public void recipeDelete(int rnumber) {
		sql.delete("rm.recipedelete", rnumber);
	}

	public void recipeUpdate(RecipeDTO recipe) {
		sql.update("rm.recipeupdate", recipe);
		
	}

	public void materialUpdate(MaterialDTO material) {
		sql.update("rm.materialupdate", material);
		
	}

	public void orderUpdate(OrderDTO order) {
		sql.update("rm.orderupdate", order);
	}

	public List<RecipeDTO> recipeRanking() {
		return sql.selectList("rm.reciperanking");
	}

	public List<RecipeDTO> recipeSearch(String keyword) {
		return sql.selectList("rm.recipesearch", keyword);
	}

	public List<ReportDTO> totalReport() {
		return sql.selectList("rm.totalreport");
	}
	
	public List<RecipeDTO> myRecipeList() {
		return sql.selectList("rm.recipelist");
	}
	
	public List<ReportDTO> myReport() {
		return sql.selectList("rm.myreport");
	}
	
//	public List<PurchaserDTO> myBuyRecipe() {
//		return sql.selectList("rm.mybuyrecipe");
//	}
}