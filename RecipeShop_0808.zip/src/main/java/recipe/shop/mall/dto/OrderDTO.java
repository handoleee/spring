package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class OrderDTO {

	private int onumber;
	private int ornumber;
	private String ofilename;
	private String ocontents;
	
}
