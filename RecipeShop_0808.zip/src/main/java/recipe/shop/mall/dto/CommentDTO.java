package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class CommentDTO {

	private int cnumber;
	private int crnumber;
	private String cname;
	private String ccontents;
	private String cgrade;
	
}
