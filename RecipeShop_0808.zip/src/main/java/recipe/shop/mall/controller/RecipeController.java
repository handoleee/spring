package recipe.shop.mall.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import recipe.shop.mall.dto.MaterialDTO;
import recipe.shop.mall.dto.OrderDTO;
import recipe.shop.mall.dto.RecipeDTO;
import recipe.shop.mall.dto.ReportDTO;
import recipe.shop.mall.service.RecipeService;

@Controller
public class RecipeController {

	@Autowired
	private RecipeService rs;
	
	private ModelAndView mav;
	
	// 레시피 목록
	@RequestMapping(value="/recipelist")
	public ModelAndView recipeList() {
		mav = rs.recipeList();
		
		return mav;
	}
	
	// 레시피 등록 페이지
	@RequestMapping(value="/recipewritepage")
	public String recipeWritePage() {
		return "recipewrite";
	}
	
	// 레시피 등록 처리
	@RequestMapping(value="/recipewrite")
	public ModelAndView recipeWrite(@ModelAttribute RecipeDTO recipe,
									@ModelAttribute MaterialDTO material,
									@ModelAttribute OrderDTO order) {
		mav = rs.recipeWrite(recipe, material, order);
		
		return mav;
	}
	
	// 레시피 상세 조회
	@RequestMapping(value="/recipeview")
	public ModelAndView recipeView(@RequestParam("rnumber") int rnumber) {
		mav = rs.recipeView(rnumber);
		
		return mav;
	}
	
	// 레시피 신고 페이지
	@RequestMapping(value="/recipereport")
	public ModelAndView recipeReport(@RequestParam("rnumber") int rnumber) {
		mav = rs.recipeReport(rnumber);
		
		return mav;
	}
	
	// 레시피 신고 처리
	@RequestMapping(value="/recipereportprocess")
	public ModelAndView recipeReportProcess(@ModelAttribute ReportDTO report) {
		mav = rs.recipeReportProcess(report);
		
		return mav;
	}
	
	// 레시피 삭제
	@RequestMapping(value="/recipedelete")
	public ModelAndView recipeDelete(@RequestParam("rnumber") int rnumber) {
		mav = rs.recipeDelete(rnumber);
		
		return mav;
	}
	
	// 레시피 수정
	@RequestMapping(value="/recipeupdate")
	public ModelAndView recipeUpdate(@RequestParam("rnumber") int rnumber) {
		mav = rs.recipeUpdate(rnumber);
		
		return mav;
	}
	
	// 레시피 수정 처리
	@RequestMapping(value="/recipeupdateprocess")
	public ModelAndView recipeUpdateProcess(@ModelAttribute RecipeDTO recipe,
											@ModelAttribute MaterialDTO material,
											@ModelAttribute OrderDTO order) {
		
		mav = rs.recipeUpdateProcess(recipe, material, order);
		
		return mav;
	}
	
	// 레시피 랭킹
	@RequestMapping(value="/reciperanking")
	public ModelAndView recipeRanking() {
		mav = rs.recipeRanking();
		
		return mav;
	}
	
	// 레시피 검색
	@RequestMapping(value="/recipesearch")
	public ModelAndView recipeSearch(@RequestParam("keyword") String keyword) {
		mav = rs.recipeSearch(keyword);
		return mav;
	}
	
	//회원신고내역
		@RequestMapping(value="/reportlist")
		public ModelAndView totalReport() {
			mav = rs.totalReport();
			return mav;
		}
	
	//내 레시피목록
	@RequestMapping(value="/myrecipelist")
	public ModelAndView myRecipeList() {
		mav = rs.myRecipeList();
		return mav;
	}
	
	//내 신고내역
	@RequestMapping(value="/myreport")
	public ModelAndView myReport() {
		mav = rs.myReport();
		return mav;
	}
	
//	//내가 구매한 레시피 목록
//	@RequestMapping(value="/mybuyrecipe")
//	public ModelAndView myBuyRecipe() {
//		mav = rs.myBuyRecipe();
//		return mav;
//	}
}
