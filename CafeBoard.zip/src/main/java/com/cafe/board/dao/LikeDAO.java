package com.cafe.board.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cafe.board.dto.LikeDTO;

@Repository
public class LikeDAO {
	
	@Autowired
	private SqlSessionTemplate sql;

	public int likeList(LikeDTO like) {
		return sql.insert("lm.likelist", like);
	}
	
//	public LikeDTO addLikeList(String loginId) {
//		return sql.selectOne("lm.addlikelist", loginId);
//	}
//	
//	public int addLikeListProcess(LikeDTO like) {
//		return sql.update("lm.addlikelistprocess", like);
//	}
	
//	public List<LikeDTO> likeList(String lid) {
//		return sql.selectList("lm.likelist", lid);
//	}
//
	

	

	

}
