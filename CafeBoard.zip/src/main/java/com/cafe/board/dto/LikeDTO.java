package com.cafe.board.dto;

import lombok.Data;

@Data
public class LikeDTO {
	private int lnumber;
	private int lbrandnum;
	private String lid;
}
