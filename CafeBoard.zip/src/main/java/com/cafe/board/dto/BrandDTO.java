package com.cafe.board.dto;

import lombok.Data;

@Data
public class BrandDTO {
	private int rnumber;
	private String rbrand;
}
