package com.cafe.board.dto;

import lombok.Data;

@Data
public class MemberDTO {
	private String mid;
	private String mpassword;
	private String mphone;
	private String mname;
}
