package recipe.shop.mall.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;


import recipe.shop.mall.dao.CartDAO;
import recipe.shop.mall.dto.CartDTO;

@Service
public class CartService {
	
	@Autowired
	private CartDAO cdao;

	private ModelAndView mav;
	
	
	
	// 장바구니 담기
	public ModelAndView cart(CartDTO cart) {
		mav = new ModelAndView();
		int insertResult = 0;
		insertResult = cdao.cart(cart);
		if(insertResult > 0) {
			mav.setViewName("redirect:/shoplist");
		} else {
			mav.setViewName("home");
		}
		return mav;
	}


	// 내 장바구니
	public ModelAndView BaskList(String loginMember) {
		mav = new ModelAndView();
		
		List<CartDTO> basklist = cdao.yeyagList(loginMember);
		
		mav.addObject("BaskList", basklist);
		mav.setViewName("basklist");
		
		return mav;
	}

	// 장바구니 취소
	public ModelAndView cartDelete(int sbnumber) {
		mav = new ModelAndView();
		
		cdao.cartDelete(sbnumber);
	
		mav.setViewName("basklist");
		
		return mav;
	}

	// 수량 수정 화면
	public ModelAndView cartUpdate(int sbnumber) {
		mav = new ModelAndView();
		CartDTO cart = cdao.cartupdate(sbnumber);
		mav.addObject("cartUpdate", cart);
		mav.setViewName("cartupdate");
		return mav;
	}

}
