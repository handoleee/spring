package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class MaterialDTO {
	
	private int mtnumber;
	private int mtrnumber;
	private String mtname;
	private String mtvolume;
	
}
