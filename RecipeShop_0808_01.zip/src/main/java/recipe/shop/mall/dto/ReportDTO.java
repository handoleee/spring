package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class ReportDTO {
	private int rpnumber;
	private int rprnumber;
	private String rpname;
	private String rpcontents;
	private String rpcheck;
	private String rpanswer;
}
