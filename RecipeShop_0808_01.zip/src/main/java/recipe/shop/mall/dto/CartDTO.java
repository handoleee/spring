package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class CartDTO {
		
		private int sbnumber;
		private String sbmid;
		private int sbsnumber;
		private String sbname;
		private int sbquantity;
		private int sbprice;
		private int sum;
}
