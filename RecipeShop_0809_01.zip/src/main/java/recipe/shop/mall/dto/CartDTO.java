package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class CartDTO {
		
		private int sbnumber;
		private String sbmid;
		private String sbname;
		private int sbsnumber;
		private int sbquantity;
		private int sbprice;
		private int sum;
		public int getSbnumber() {
			return sbnumber;
		}
		public void setSbnumber(int sbnumber) {
			this.sbnumber = sbnumber;
		}
		public String getSbmid() {
			return sbmid;
		}
		public void setSbmid(String sbmid) {
			this.sbmid = sbmid;
		}

		public String getSbname() {
			return sbname;
		}
		public void setSbname(String sbname) {
			this.sbname = sbname;
		}
		public int getSbquantity() {
			return sbquantity;
		}
		public void setSbquantity(int sbquantity) {
			this.sbquantity = sbquantity;
		}
		public int getSbprice() {
			return sbprice;
		}
		public void setSbprice(int sbprice) {
			this.sbprice = sbprice;
		}
		public int getSum() {
			return sum;
		}
		public void setSum(int sum) {
			this.sum = sum;
		}
		public int getSbsnumber() {
			return sbsnumber;
		}
		public void setSbsnumber(int sbsnumber) {
			this.sbsnumber = sbsnumber;
		}
		
		
		
		
		
		
		
		
		
		
		
		
}
