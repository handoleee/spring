package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class RecipeDTO {
	private int rnumber;
	private String rname;
	private String rtitle;
	private String rcontents;
	private String rcategory;
	private String rperson;
	private String rtag;
	private String rprice;
	private String rfilename;
	private String rlevel;
	private int rhits;
	private int rlikes;
	public int getRnumber() {
		return rnumber;
	}
	public void setRnumber(int rnumber) {
		this.rnumber = rnumber;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRtitle() {
		return rtitle;
	}
	public void setRtitle(String rtitle) {
		this.rtitle = rtitle;
	}
	public String getRcontents() {
		return rcontents;
	}
	public void setRcontents(String rcontents) {
		this.rcontents = rcontents;
	}
	public String getRcategory() {
		return rcategory;
	}
	public void setRcategory(String rcategory) {
		this.rcategory = rcategory;
	}
	public String getRperson() {
		return rperson;
	}
	public void setRperson(String rperson) {
		this.rperson = rperson;
	}
	public String getRtag() {
		return rtag;
	}
	public void setRtag(String rtag) {
		this.rtag = rtag;
	}
	public String getRprice() {
		return rprice;
	}
	public void setRprice(String rprice) {
		this.rprice = rprice;
	}
	public String getRfilename() {
		return rfilename;
	}
	public void setRfilename(String rfilename) {
		this.rfilename = rfilename;
	}
	public String getRlevel() {
		return rlevel;
	}
	public void setRlevel(String rlevel) {
		this.rlevel = rlevel;
	}
	public int getRhits() {
		return rhits;
	}
	public void setRhits(int rhits) {
		this.rhits = rhits;
	}
	public int getRlikes() {
		return rlikes;
	}
	public void setRlikes(int rlikes) {
		this.rlikes = rlikes;
	}
	
	
	
}
