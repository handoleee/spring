 package recipe.shop.mall.dto;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class ShopDTO {
	private int snumber; // 재료번호
	private String sname; // 재료이름
	private int sprice; // 가격
	private int sstock; // 재고
	private String sorigin; // 원산지
	private String smake; // 제조사
	private String sbox; // 구성
	private String stime; // 유통기한
	private String scontents; // 상세정보
	private MultipartFile sfile; // 대표사진
	private String sfilename; // 파일을 담긴 위한 필드
	public int getSnumber() {
		return snumber;
	}
	public void setSnumber(int snumber) {
		this.snumber = snumber;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getSprice() {
		return sprice;
	}
	public void setSprice(int sprice) {
		this.sprice = sprice;
	}
	public int getSstock() {
		return sstock;
	}
	public void setSstock(int sstock) {
		this.sstock = sstock;
	}
	public String getSorigin() {
		return sorigin;
	}
	public void setSorigin(String sorigin) {
		this.sorigin = sorigin;
	}
	public String getSmake() {
		return smake;
	}
	public void setSmake(String smake) {
		this.smake = smake;
	}
	public String getSbox() {
		return sbox;
	}
	public void setSbox(String sbox) {
		this.sbox = sbox;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getScontents() {
		return scontents;
	}
	public void setScontents(String scontents) {
		this.scontents = scontents;
	}
	public MultipartFile getSfile() {
		return sfile;
	}
	public void setSfile(MultipartFile sfile) {
		this.sfile = sfile;
	}
	public String getSfilename() {
		return sfilename;
	}
	public void setSfilename(String sfilename) {
		this.sfilename = sfilename;
	}
	
	
	
	
}
