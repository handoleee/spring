package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class MaterialDTO {
	
	private int mtnumber;
	private int mtrnumber;
	private String mtname;
	private String mtvolume;
	public int getMtnumber() {
		return mtnumber;
	}
	public void setMtnumber(int mtnumber) {
		this.mtnumber = mtnumber;
	}
	public int getMtrnumber() {
		return mtrnumber;
	}
	public void setMtrnumber(int mtrnumber) {
		this.mtrnumber = mtrnumber;
	}
	public String getMtname() {
		return mtname;
	}
	public void setMtname(String mtname) {
		this.mtname = mtname;
	}
	public String getMtvolume() {
		return mtvolume;
	}
	public void setMtvolume(String mtvolume) {
		this.mtvolume = mtvolume;
	}
	
}
