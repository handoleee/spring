package recipe.shop.mall.dto;

import lombok.Data;

@Data
public class OrderDTO {

	private int onumber;
	private int ornumber;
	private String ofilename;
	private String ocontents;
	public int getOnumber() {
		return onumber;
	}
	public void setOnumber(int onumber) {
		this.onumber = onumber;
	}
	public int getOrnumber() {
		return ornumber;
	}
	public void setOrnumber(int ornumber) {
		this.ornumber = ornumber;
	}
	public String getOfilename() {
		return ofilename;
	}
	public void setOfilename(String ofilename) {
		this.ofilename = ofilename;
	}
	public String getOcontents() {
		return ocontents;
	}
	public void setOcontents(String ocontents) {
		this.ocontents = ocontents;
	}
	
}
